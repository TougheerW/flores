onload = () =>{
    document.body.classList.remove("container");
};

function mostrarMensaje() {
    alert("Mañana tendrás otros 2 detalles. Espero te haya gustado esto, amor. Le he dedicado mucho tiempo, la verdad, después de muchos errores y de consultar a compañeros, salió esto, amor. ❤");
    }